export abstract class FormatoDeElemento {
    abstract desenhar(): void;
    abstract redimensionar(): void;
}
